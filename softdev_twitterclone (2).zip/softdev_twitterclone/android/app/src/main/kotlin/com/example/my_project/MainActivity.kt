package com.softdev.twitterclone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
